"use client";

import VisitDetail from "./patientDashboard/visitDetail";

export default function Home() {
  return (
    <>
      <div className="bg-[#708E86] rounded-xl p-6 text-white [&_strong]:font-semibold sm:[&_strong]:text-[24px] [&_strong]:text-[20px] mb-3 text-[15px] [&_p]:pt-2 [&_p]:font-normal [&_p]:text-[#FFFFFFCC]">
        <strong>Welcome to Rx ReLeaf</strong>
        <p>Complete the form below to start your urgent care consultation. A licensed provider will review your information and respond within minutes.</p>
      </div>
      <VisitDetail mode="public" />
    </>
  );
}