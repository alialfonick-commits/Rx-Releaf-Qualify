import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function DELETE(
    req: Request,
    { params }: { params: Promise<{ id: string }> }
  ) {
    const session = await getServerSession(authOptions)
  
    if (!session || session.user.role !== "STAFF") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
  
    const { id: examId } = await params 
  
    try {
      await prisma.exam.delete({
        where: { id: examId }
      })
  
      return NextResponse.json({ success: true })
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to delete exam" },
        { status: 500 }
      )
    }
}