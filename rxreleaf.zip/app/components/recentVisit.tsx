'use client'
import { ArrowRight, FileChartColumnIncreasing } from "lucide-react"
import Link from "next/link"
import { TableWrap } from "./tableWrap"
import { useEffect, useState } from "react"

export default function RecentVisit() {
  const [visits, setVisits] = useState<any[]>([])

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    const res = await fetch("/api/staff/dashboard")
    const data = await res.json()
    setVisits(data.cases)
  }
	return (
		<div className="bg-[#FFFFFF] border border-[#D7DED3] rounded-xl px-4 py-5 mt-3">
			<div className="pb-5 flex items-center justify-between">
        <div className="flex items-center gap-3 [&_strong]:font-semibold sm:[&_strong]:text-[20px] [&_strong]:text-[18px]">
          <FileChartColumnIncreasing color="#5E6E66" className="bg-[#CCD7C6] size-10 p-2 rounded-lg" />
          <strong>Recent Visits</strong>
        </div>
					<Link href="/staff/visits" className="flex text-[#476B59] font-medium gap-1 items-center hover:text-[#DFA620]">View All <ArrowRight size={17} /></Link>
			</div>
			<TableWrap visits={visits} />
		</div>
	)
}